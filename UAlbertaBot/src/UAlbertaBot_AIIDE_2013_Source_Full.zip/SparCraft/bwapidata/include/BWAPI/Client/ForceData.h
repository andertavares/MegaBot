#pragma once

namespace BWAPI
{
  struct ForceData
  {
    char name[32];
  };
}
